/*
 * builtin_freq.c
 *
 * Week 1: placeholder only.
 * This translation unit must not be empty because the project builds with
 * -Wpedantic -Werror.
 *
 * Replace with real implementation in future week.
 */

#include "diamondcore.h"

/* Placeholder symbol to keep translation unit non-empty. */
int dc_freq_placeholder = 0;
